import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowRight, BookOpen, Brain, Menu, X, Sparkles, GraduationCap, Trophy,
  FlaskConical, Lightbulb, MessageCircle, Clock3, ChevronRight, Languages,
  Send, CheckCircle2, Headphones, Target, Star, LayoutDashboard, UserPlus,
  Gamepad2, BookMarked, LogOut, Users, Plus, ShieldCheck, RefreshCw
} from "lucide-react";
import { supabase, supabaseReady } from "./supabase";
import "./styles.css";

const courses = [
  { name: "Mathematics", level: "JSS 1 – SS 3", icon: "∑", tone: "lavender", lessons: "24 lessons" },
  { name: "English Language", level: "JSS 1 – SS 3", icon: "Aa", tone: "peach", lessons: "18 lessons" },
  { name: "Basic Science", level: "JSS 1 – SS 3", icon: "⚗", tone: "mint", lessons: "16 lessons" },
  { name: "Computer Studies", level: "All levels", icon: "⌘", tone: "blue", lessons: "12 lessons" }
];
const quizQuestions = [
  { q: "What is 12 × 8?", ha: "Nawa ne 12 × 8?", options: ["86", "96", "108", "88"], answer: 1, explain: "12 × 8 = 96. Ka ninka 12 sau 8 ka samu 96." },
  { q: "Which word is a noun?", ha: "Wanne kalma ce suna (noun)?", options: ["Run", "Beautiful", "Teacher", "Quickly"], answer: 2, explain: "Teacher is a noun because it names a person. Teacher suna ne saboda yana nuna mutum." },
  { q: "What planet do we live on?", ha: "A wace duniya muke rayuwa?", options: ["Mars", "Venus", "Earth", "Jupiter"], answer: 2, explain: "We live on Earth. Muna rayuwa a duniyar Earth." }
];

function App() {
  const [page, setPage] = useState("home");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [language, setLanguage] = useState("Hausa + English");
  const [messages, setMessages] = useState([{ role: "assistant", text: "Sannu! I’m Oma, your AI teacher. What would you like to learn today?\n\nSannu! Ni ce Oma, malamar AI. Me kake son koya yau?" }]);
  const [question, setQuestion] = useState("");
  const [busy, setBusy] = useState(false);
  const [quizIndex, setQuizIndex] = useState(0);
  const [selected, setSelected] = useState(null);
  const [score, setScore] = useState(0);
  const [quizDone, setQuizDone] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState("signup");
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [authBusy, setAuthBusy] = useState(false);
  const [authMessage, setAuthMessage] = useState("");
  const [adminData, setAdminData] = useState({ students: 0, courses: [], enrollments: 0, attempts: 0 });
  const [newCourse, setNewCourse] = useState({ title: "", subject: "", description: "" });
  const [adminMessage, setAdminMessage] = useState("");

  const go = (next) => { setPage(next); setMobileOpen(false); window.scrollTo({ top: 0, behavior: "smooth" }); };

  async function loadProfile(sessionUser) {
    if (!supabase || !sessionUser) { setProfile(null); return; }
    const { data } = await supabase.from("profiles").select("id, full_name, preferred_language, role").eq("id", sessionUser.id).maybeSingle();
    setProfile(data || null);
  }
  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => {
      setUser(data.session?.user || null);
      if (data.session?.user) loadProfile(data.session.user);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user || null);
      if (session?.user) setTimeout(() => loadProfile(session.user), 0);
      else setProfile(null);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  async function handleAuth(e) {
    e.preventDefault();
    if (!supabase) return;
    setAuthBusy(true); setAuthMessage("");
    const form = new FormData(e.currentTarget);
    const email = String(form.get("email") || "");
    const password = String(form.get("password") || "");
    const fullName = String(form.get("full_name") || "");
    let result;
    if (authMode === "signup") {
      result = await supabase.auth.signUp({ email, password, options: { data: { full_name: fullName } } });
      if (!result.error) setAuthMessage("An tabbatar da rajista. Duba email ɗinka idan an kunna email confirmation.");
    } else {
      result = await supabase.auth.signInWithPassword({ email, password });
    }
    if (result.error) setAuthMessage(result.error.message);
    else if (authMode === "login") { setAuthOpen(false); go("dashboard"); }
    setAuthBusy(false);
  }

  async function signOut() {
    if (supabase) await supabase.auth.signOut();
    setUser(null); setProfile(null); go("home");
  }

  async function loadAdmin() {
    if (!supabase || profile?.role !== "admin") return;
    setAdminMessage("Ana ɗauko bayanai...");
    const [students, courseRows, enrollments, attempts] = await Promise.all([
      supabase.from("profiles").select("id, full_name, role, created_at").order("created_at", { ascending: false }),
      supabase.from("courses").select("id, title, subject, description, is_published, created_at").order("created_at", { ascending: false }),
      supabase.from("enrollments").select("id", { count: "exact", head: true }),
      supabase.from("quiz_attempts").select("id", { count: "exact", head: true })
    ]);
    const err = students.error || courseRows.error || enrollments.error || attempts.error;
    if (err) setAdminMessage(err.message);
    else {
      setAdminData({ students: students.data?.filter(x => x.role === "student").length || 0, courses: courseRows.data || [], enrollments: enrollments.count || 0, attempts: attempts.count || 0 });
      setAdminMessage("");
    }
  }
  useEffect(() => { if (page === "admin" && profile?.role === "admin") loadAdmin(); }, [page, profile]);

  async function addCourse(e) {
    e.preventDefault();
    if (!supabase) return;
    const { error } = await supabase.from("courses").insert({ ...newCourse, level: "All levels", language: "Hausa + English", is_published: false });
    if (error) setAdminMessage(error.message);
    else { setNewCourse({ title: "", subject: "", description: "" }); setAdminMessage("An ƙara course. Za ka iya publish ɗinsa daga baya."); loadAdmin(); }
  }
  async function toggleCourse(course) {
    const { error } = await supabase.from("courses").update({ is_published: !course.is_published }).eq("id", course.id);
    if (error) setAdminMessage(error.message); else loadAdmin();
  }

  const sendQuestion = async (e) => {
    e.preventDefault();
    if (!question.trim() || busy) return;
    const current = question.trim();
    setMessages(m => [...m, { role: "user", text: current }]); setQuestion(""); setBusy(true);
    try {
      const res = await fetch("/api/tutor", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: current, language }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "AI is not available.");
      setMessages(m => [...m, { role: "assistant", text: data.answer }]);
    } catch (err) {
      setMessages(m => [...m, { role: "assistant", text: `${err.message}\n\nDemo: 2 + 2 = 4. Ka tara, idan ka haɗa 2 da 2 za ka samu 4.` }]);
    } finally { setBusy(false); }
  };
  const answerQuiz = (i) => { if (selected !== null) return; setSelected(i); if (i === quizQuestions[quizIndex].answer) setScore(s => s + 1); };
  const nextQuiz = () => { if (quizIndex === quizQuestions.length - 1) setQuizDone(true); else { setQuizIndex(i => i + 1); setSelected(null); } };
  const nav = [["home","Home"],["courses","Courses"],["tutor","AI Teacher"],["practice","Exam Practice"],["games","Learning Games"]];

  return <div className="app-shell">
    <header className="topbar">
      <button className="brand" onClick={() => go("home")}><span className="brand-mark"><Brain size={22}/></span><span>KABIR<span className="brand-accent">AI</span><small>LEARNING</small></span></button>
      <nav className="desktop-nav">{nav.map(([id,label]) => <button key={id} className={page===id?"active":""} onClick={() => go(id)}>{label}</button>)}</nav>
      <div className="top-actions">
        {user ? <><button className="login-link" onClick={() => go(profile?.role==="admin"?"admin":"dashboard")}>{profile?.full_name || user.email}</button><button className="primary small" onClick={signOut}><LogOut size={14}/> Sign out</button></> : <><button className="login-link" onClick={() => {setAuthMode("login");setAuthOpen(true);}}>Log in</button><button className="primary small" onClick={() => {setAuthMode("signup");setAuthOpen(true);}}>Join free <ArrowRight size={15}/></button></>}
        <button className="menu-btn" onClick={() => setMobileOpen(v=>!v)}>{mobileOpen?<X/>:<Menu/>}</button>
      </div>
    </header>
    {mobileOpen && <nav className="mobile-nav">{nav.map(([id,label])=><button key={id} onClick={()=>go(id)}>{label}</button>)}{user && <button onClick={()=>go(profile?.role==="admin"?"admin":"dashboard")}>My dashboard</button>}</nav>}

    {page==="home" && <main>
      <section className="hero section-wrap"><div className="hero-copy"><div className="eyebrow"><Sparkles size={14}/> YOUR LEARNING JOURNEY STARTS HERE</div><h1>Learn for school.<br/><span>Build for life</span><br/><span className="gradient-text">beyond it.</span></h1><p className="hero-sub">Lessons, exam practice and learning games — with Oma, your AI teacher in Hausa and English.</p><div className="hero-actions"><button className="primary" onClick={()=>go("tutor")}>Start learning <ArrowRight size={17}/></button><button className="secondary" onClick={()=>go("practice")}>Try free practice <ArrowRight size={17}/></button></div><div className="trust-row"><span><CheckCircle2 size={15}/> Learn at your pace</span><span><Languages size={15}/> Hausa + English</span></div></div>
      <div className="hero-art"><div className="orb orb-one"></div><div className="orb orb-two"></div><div className="tutor-card"><div className="tutor-head"><div className="oma-avatar">O</div><div><b>Meet Oma</b><small>Your friendly AI teacher</small></div><span className="online-dot"></span></div><div className="bubble bubble-ai">Sannu! Ready to learn something new today?</div><div className="bubble bubble-user">Yes! Teach me mathematics.</div><div className="mini-answer"><span className="sparkle">✦</span><div><b>Let's make it simple.</b><small>Small steps. Big understanding.</small></div></div><div className="wave-bars">{Array.from({length:18},(_,i)=><i key={i}/>)}</div></div><div className="float-icon float-book"><BookOpen/></div><div className="float-icon float-star"><Star/></div><div className="float-icon float-cap"><GraduationCap/></div><div className="floating-note"><Trophy size={18}/><span><b>Keep growing!</b><small>Every lesson counts</small></span></div></div></section>
      <section className="stats-strip section-wrap"><div><b>2</b><span>Teaching languages</span></div><div><b>4+</b><span>Learning subjects</span></div><div><b>Anytime</b><span>Learn at your pace</span></div><div><b>100%</b><span>Curiosity encouraged</span></div></section>
      <section className="section-wrap feature-section"><div className="section-heading"><div><div className="eyebrow">ONE PLATFORM, MANY POSSIBILITIES</div><h2>Everything you need to <span className="gradient-text">grow.</span></h2></div><button className="text-link" onClick={()=>go("courses")}>Explore learning <ArrowRight size={16}/></button></div><div className="feature-grid"><Feature icon={<MessageCircle/>} tone="lavender" title="AI Teacher — Oma" desc="Ask questions and get simple, step-by-step explanations in Hausa or English." onClick={()=>go("tutor")}/><Feature icon={<Target/>} tone="peach" title="Exam practice" desc="Prepare with practice questions inspired by JAMB, WAEC and NECO topics." onClick={()=>go("practice")}/><Feature icon={<Gamepad2/>} tone="mint" title="Learning games" desc="Build confidence through fun challenges, quick quizzes and brain games." onClick={()=>go("games")}/><Feature icon={<LayoutDashboard/>} tone="blue" title="Student dashboard" desc="See your learning activity, completed lessons and practice progress." onClick={()=>go("dashboard")}/></div></section>
      <section className="section-wrap course-section"><div className="section-heading"><div><div className="eyebrow">PICK UP A NEW SKILL</div><h2>Popular learning paths</h2></div><button className="text-link" onClick={()=>go("courses")}>All subjects <ArrowRight size={16}/></button></div><div className="course-grid">{courses.map(c=><Course key={c.name} course={c} onClick={()=>go("courses")}/>)}</div></section>
      <section className="cta-band section-wrap"><div><div className="eyebrow">YOUR NEXT CHAPTER STARTS NOW</div><h2>Curiosity looks good on you.</h2><p>Ask your first question. Learn one new thing today.</p></div><button className="primary" onClick={()=>go("tutor")}>Meet Oma <ArrowRight size={17}/></button></section>
    </main>}

    {page==="courses" && <main className="page-main section-wrap"><PageTitle eyebrow="EXPLORE AND DISCOVER" title="Find your learning path" desc="Choose a subject and build your knowledge one lesson at a time."/><div className="course-grid course-grid-large">{courses.map(c=><Course key={c.name} course={c} onClick={()=>go("tutor")}/>)}</div><div className="notice"><Lightbulb size={19}/><span><b>Learning tip:</b> Try explaining what you learn to someone else. Teaching helps you remember.</span></div></main>}

    {page==="tutor" && <main className="page-main section-wrap"><PageTitle eyebrow="YOUR PERSONAL LEARNING COMPANION" title="Learn with Oma" desc="Ask anything you're learning. Oma will explain it in simple steps."/><div className="chat-layout"><aside className="chat-sidebar"><div className="oma-profile"><div className="oma-avatar big">O</div><div><b>Oma AI Teacher</b><small><span className="online-dot"></span> Ready to help</small></div></div><label className="field-label">Teaching language</label><select value={language} onChange={e=>setLanguage(e.target.value)}><option>Hausa + English</option><option>Hausa</option><option>English</option></select><div className="suggestions"><b>Try asking</b>{["Explain fractions to me","Menene photosynthesis?","Teach me English grammar","What is 5 × 9?"].map(s=><button key={s} onClick={()=>setQuestion(s)}>{s}<ChevronRight size={14}/></button>)}</div><div className="safe-note"><Headphones size={17}/> Learn with patience. Ask follow-up questions whenever you need.</div></aside><section className="chat-panel"><div className="chat-top"><div><b><span className="online-dot"></span> Oma is ready</b><small>AI learning assistant</small></div><span className="language-pill"><Languages size={14}/>{language}</span></div><div className="chat-messages">{messages.map((m,i)=><div key={i} className={`message ${m.role}`}><div className="message-avatar">{m.role==="assistant"?"O":"You"}</div><div className="message-text">{m.text}</div></div>)}{busy&&<div className="typing">Oma is thinking<span>•••</span></div>}</div><form className="chat-compose" onSubmit={sendQuestion}><input value={question} onChange={e=>setQuestion(e.target.value)} placeholder="Ask Oma a question... / Tambayi Oma..."/><button className="send-btn" disabled={busy||!question.trim()} aria-label="Send"><Send size={18}/></button></form><p className="demo-caption">AI answers need the OPENAI_API_KEY environment variable in Netlify.</p></section></div></main>}

    {page==="practice" && <main className="page-main section-wrap"><PageTitle eyebrow="PREPARE WITH CONFIDENCE" title="Exam practice" desc="Try a short sample quiz. Learn from every answer."/><div className="quiz-shell"><div className="quiz-meta"><span className="pill">GENERAL KNOWLEDGE</span><span><Clock3 size={15}/> 3 questions</span></div>{!quizDone?<><div className="progress-track"><span style={{width:`${(quizIndex/quizQuestions.length)*100}%`}}/></div><div className="question-count">QUESTION {quizIndex+1} OF {quizQuestions.length}</div><h2>{quizQuestions[quizIndex].q}</h2><p className="ha-question">{quizQuestions[quizIndex].ha}</p><div className="answer-list">{quizQuestions[quizIndex].options.map((o,i)=><button key={o} onClick={()=>answerQuiz(i)} className={`answer-option ${selected===i?(i===quizQuestions[quizIndex].answer?"correct":"wrong"):""} ${selected!==null&&i===quizQuestions[quizIndex].answer?"correct":""}`}><span>{String.fromCharCode(65+i)}</span>{o}</button>)}</div>{selected!==null&&<div className="explanation"><CheckCircle2 size={18}/><span>{quizQuestions[quizIndex].explain}</span></div>}<div className="quiz-footer"><span>Score: {score}/{quizQuestions.length}</span><button className="primary" disabled={selected===null} onClick={nextQuiz}>{quizIndex===quizQuestions.length-1?"See result":"Next question"} <ArrowRight size={16}/></button></div></>:<div className="quiz-result"><div className="result-icon"><Trophy size={34}/></div><h2>Well done!</h2><p>You scored {score} out of {quizQuestions.length}.</p><p className="ha-question">Ka yi kokari! Ci gaba da koyo.</p><button className="primary" onClick={()=>{setQuizIndex(0);setSelected(null);setScore(0);setQuizDone(false);}}>Try again <ArrowRight size={16}/></button></div>}</div></main>}

    {page==="games" && <main className="page-main section-wrap"><PageTitle eyebrow="PLAY. THINK. GROW." title="Learning games" desc="Short activities that make learning feel like play."/><div className="feature-grid game-grid"><Feature icon={<Brain/>} tone="lavender" title="Brain booster" desc="Warm up your mind with quick thinking questions." onClick={()=>go("practice")}/><Feature icon={<BookMarked/>} tone="peach" title="Word builder" desc="Grow your English and Hausa vocabulary." onClick={()=>go("practice")}/><Feature icon={<FlaskConical/>} tone="mint" title="Science explorer" desc="Discover everyday science through fun facts." onClick={()=>go("courses")}/><Feature icon={<Trophy/>} tone="blue" title="Quiz challenge" desc="Test what you know and celebrate your progress." onClick={()=>go("practice")}/></div><div className="notice"><Lightbulb size={19}/><span>These are starter activities. More interactive games can be added as the platform grows.</span></div></main>}

    {page==="dashboard" && <main className="page-main section-wrap"><PageTitle eyebrow="YOUR LEARNING SPACE" title="Student dashboard" desc="Your learning space and account details."/>{!user?<div className="notice"><UserPlus size={19}/><span>Shiga ko yi rajista domin samun dashboard ɗinka. <button className="inline-link" onClick={()=>{setAuthMode("signup");setAuthOpen(true);}}>Create account</button></span></div>:<><div className="dashboard-grid"><div className="dash-card"><span className="dash-icon lavender"><BookOpen/></span><small>Account name</small><b>{profile?.full_name||"Student"}</b><span>{user.email}</span></div><div className="dash-card"><span className="dash-icon mint"><ShieldCheck/></span><small>Account role</small><b>{profile?.role||"student"}</b><span>Secure Supabase account</span></div><div className="dash-card"><span className="dash-icon peach"><Languages/></span><small>Language</small><b>{profile?.preferred_language||"Hausa + English"}</b><span>Learning preference</span></div></div>{profile?.role==="admin"&&<button className="primary" onClick={()=>go("admin")}>Open Admin Dashboard <ArrowRight size={16}/></button>}</>}</main>}

    {page==="admin" && <main className="page-main section-wrap"><PageTitle eyebrow="PLATFORM MANAGEMENT" title="Admin dashboard" desc="Manage student accounts, courses and learning activity."/>{!user?<div className="notice"><ShieldCheck size={19}/><span>Admin access yana buƙatar login.</span></div>:profile?.role!=="admin"?<div className="notice"><ShieldCheck size={19}/><span>Ba a ba wannan account izinin admin ba. Admin role sai an ɗora shi daga Supabase SQL Editor ta project owner.</span></div>:<><div className="dashboard-grid"><div className="dash-card"><span className="dash-icon lavender"><Users/></span><small>Students</small><b>{adminData.students}</b><span>Registered learners</span></div><div className="dash-card"><span className="dash-icon mint"><BookOpen/></span><small>Courses</small><b>{adminData.courses.length}</b><span>Published and draft</span></div><div className="dash-card"><span className="dash-icon peach"><Target/></span><small>Enrollments / Quiz attempts</small><b>{adminData.enrollments} / {adminData.attempts}</b><span>Learning activity</span></div></div><div className="admin-panel"><div className="admin-panel-head"><h2>Course management</h2><button className="secondary" onClick={loadAdmin}><RefreshCw size={15}/> Refresh</button></div><form className="course-form" onSubmit={addCourse}><input required placeholder="Course title" value={newCourse.title} onChange={e=>setNewCourse(v=>({...v,title:e.target.value}))}/><input required placeholder="Subject" value={newCourse.subject} onChange={e=>setNewCourse(v=>({...v,subject:e.target.value}))}/><input placeholder="Short description" value={newCourse.description} onChange={e=>setNewCourse(v=>({...v,description:e.target.value}))}/><button className="primary"><Plus size={16}/> Add course</button></form>{adminMessage&&<p className="admin-message">{adminMessage}</p>}<div className="admin-course-list">{adminData.courses.map(c=><div className="admin-course-row" key={c.id}><span><b>{c.title}</b><small>{c.subject} · {c.is_published?"Published":"Draft"}</small></span><button className="secondary" onClick={()=>toggleCourse(c)}>{c.is_published?"Unpublish":"Publish"}</button></div>)}</div></div><div className="admin-panel"><h2>Student accounts</h2><p className="ha-question">An nuna adadin students a sama. Ana kare bayanan kowane student da RLS.</p></div></>}</main>}

    <footer className="footer"><div className="footer-brand"><span className="brand-mark"><Brain size={20}/></span><b>KABIR AI LEARNING</b></div><p>Learn for school. Build for life beyond it.</p><div className="footer-bottom"><span>© 2026 KABIR AI LEARNING</span><span>Built for curious minds · Hausa + English</span></div></footer>

    {authOpen&&<div className="modal-backdrop" onClick={()=>setAuthOpen(false)}><div className="auth-modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setAuthOpen(false)}><X/></button><div className="brand-mark"><GraduationCap/></div><h2>{authMode==="signup"?"Create student account":"Welcome back"}</h2><p>{authMode==="signup"?"Yi rajista domin fara koyon darussa.":"Shiga domin ci gaba da karatu."}</p>{!supabaseReady?<div className="notice">Supabase environment variables ba a saita ba tukuna.</div>:<form className="auth-form" onSubmit={handleAuth}>{authMode==="signup"&&<input name="full_name" required placeholder="Full name / Cikakken suna"/>}<input name="email" type="email" required placeholder="Email address"/><input name="password" type="password" minLength="8" required placeholder="Password (at least 8 characters)"/><button className="primary full" disabled={authBusy}>{authBusy?"Please wait...":authMode==="signup"?"Create account":"Log in"} <ArrowRight size={16}/></button></form>}{authMessage&&<p className="admin-message">{authMessage}</p>}<button className="text-link auth-switch" onClick={()=>{setAuthMode(v=>v==="signup"?"login":"signup");setAuthMessage("");}}>{authMode==="signup"?"Already have an account? Log in":"New student? Create account"}</button></div></div>}
  </div>;
}

function Feature({icon,tone,title,desc,onClick}){return <button className="feature-card" onClick={onClick}><span className={`feature-icon ${tone}`}>{icon}</span><b>{title}</b><p>{desc}</p><span className="card-arrow"><ArrowRight size={17}/></span></button>}
function Course({course,onClick}){return <button className="course-card" onClick={onClick}><span className={`course-icon ${course.tone}`}>{course.icon}</span><span className="course-info"><b>{course.name}</b><small>{course.level}</small><em>{course.lessons}</em></span><ChevronRight className="course-chevron"/></button>}
function PageTitle({eyebrow,title,desc}){return <div className="page-title"><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{desc}</p></div>}
createRoot(document.getElementById("root")).render(<App/>);
