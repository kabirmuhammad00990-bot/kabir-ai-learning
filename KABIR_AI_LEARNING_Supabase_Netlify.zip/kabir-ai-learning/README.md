# KABIR AI LEARNING

Bilingual Hausa + English learning platform built with React + Vite, Supabase Auth/Database and Netlify Functions.

## Features
- Responsive learning landing page
- Oma AI tutor (requires `OPENAI_API_KEY` in Netlify)
- Sample exam practice quiz and learning games
- Supabase student signup/login
- Student dashboard
- Admin dashboard with course create/publish controls
- Supabase RLS and role-based admin policies
- Netlify deploy configuration

## Local setup
1. Install Node.js LTS.
2. Run `npm install`
3. Copy `.env.example` to `.env` and copy the provided `.env.example` to `.env` (the project URL and publishable key are already filled in).
4. Run `npm run dev`.

The Supabase publishable key is intended for browser use. Never place a Supabase secret/service-role key or OpenAI API key in Vite variables or browser code.

## Supabase project
Project ref: `wtqpknlyksftfkhnvnep`
URL: `https://wtqpknlyksftfkhnvnep.supabase.co`

A database migration has created `profiles`, `courses`, `lessons`, `enrollments`, and `quiz_attempts`. RLS is enabled. New profiles default to the `student` role. A user cannot promote their own role through the client.

### Expose public tables in the Data API
Supabase changed the default for new projects: public tables may not be exposed to the Data API automatically. In the Supabase Dashboard open **Project Settings → API → Data API** and ensure `public` is in **Exposed schemas**. The SQL migrations already grant only the required table privileges and enable RLS.

### Promote the first admin
1. Create your own account through the website signup form.
2. In Supabase Dashboard open **SQL Editor**.
3. Run this SQL, replacing the email with the exact email you registered:
   ```sql
   update public.profiles
   set role = 'admin'
   where id = (
     select id from auth.users where email = 'YOUR_REGISTERED_EMAIL'
   );
   ```
4. Sign out and sign in again. Open **Admin Dashboard**.

Only the project owner should run the promotion SQL. Do not let students choose their own role.

## Netlify deployment
1. Push the project to a GitHub repository.
2. Netlify → Add new site → Import an existing project → select the repository.
3. Build command: `npm run build`; publish directory: `dist`.
4. In Netlify Site configuration → Environment variables, set:
   - `VITE_SUPABASE_URL` = `https://wtqpknlyksftfkhnvnep.supabase.co`
   - `VITE_SUPABASE_PUBLISHABLE_KEY` = the project's publishable key
   - `OPENAI_API_KEY` = your private OpenAI API key (server-side only)
5. Redeploy the site.

## Important
- Signup may require email confirmation depending on Supabase Auth settings.
- Course cards on the home page are sample display content; Admin Dashboard creates records in Supabase.
- Admin role promotion is deliberately manual and owner-only.
- Student quiz progress persistence, lesson editor, admin student management, and advanced exam question bank are follow-on features.
