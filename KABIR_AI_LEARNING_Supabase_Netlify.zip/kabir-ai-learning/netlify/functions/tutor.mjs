export default async (request) => {
  if (request.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405, headers: { "Content-Type": "application/json" }
    });
  }

  const apiKey = Netlify.env.get("OPENAI_API_KEY");
  if (!apiKey) {
    return new Response(JSON.stringify({
      error: "AI is not connected yet. Add OPENAI_API_KEY in Netlify environment variables."
    }), { status: 503, headers: { "Content-Type": "application/json" } });
  }

  try {
    const { message, language = "Hausa da English" } = await request.json();
    if (!message || typeof message !== "string") {
      return new Response(JSON.stringify({ error: "Please enter a question." }), {
        status: 400, headers: { "Content-Type": "application/json" }
      });
    }

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4.1-mini",
        instructions: `You are Oma, the friendly AI teacher for KABIR AI LEARNING. Teach clearly at the learner's level. The learner's preferred language is ${language}. Use Hausa and English naturally when requested. Explain step by step, encourage learning, and do not simply provide exam cheating assistance.`,
        input: message
      })
    });

    const data = await response.json();
    if (!response.ok) {
      return new Response(JSON.stringify({ error: data.error?.message || "AI request failed." }), {
        status: response.status, headers: { "Content-Type": "application/json" }
      });
    }

    const answer = data.output_text || "I could not create an answer. Please try again.";
    return new Response(JSON.stringify({ answer }), {
      status: 200, headers: { "Content-Type": "application/json" }
    });
  } catch {
    return new Response(JSON.stringify({ error: "Something went wrong. Please try again." }), {
      status: 500, headers: { "Content-Type": "application/json" }
    });
  }
};